package rizky.f.sabtugas

class Users(val id: String, val name: String, val nrp: String, val jurusan : String){
    constructor() : this("", "", "", "")
}